import dash
import dash_daq as daq
import random
from random import randint
#import RPi.GPIO as GPIO
#import Freenove_DHT as DHT
import ssl
import smtplib
import imaplib
import pandas as pd
import sqlite3
from datetime import datetime
from dash import Dash, html, dcc, callback, Output, Input
from email.message import EmailMessage
import paho.mqtt.client as mqtt_client

#Setup
#Instantiate Database
conn = sqlite3.connect('data/dashboard_db')
c = conn.cursor()

c.execute("""
    CREATE TABLE IF NOT EXISTS readings
    ([datetime] DATE PRIMARY KEY, [temp_reading] INTEGER, [hum_reading] INTEGER, [light_reading] INTEGER)
""")

c.execute("""
    CREATE TABLE IF NOT EXISTS account
    ([id] TEXT PRIMARY KEY, [email] TEXT, [pref_temp] INTEGER, [pref_light] INTEGER)
""")

conn.commit

#Insert Test Account
#c.execute("""
#INSERT INTO account VALUES('AAA AAA AAA AAA', 'example@email.com', 30, 600)
#"""
#)

#Set reading defaults
accountId ="000 000 000 000"
temp = 999
humid = 999
light = 99999
receiver = 'tomriv117@outlook.com' #admin email

#Setup GPIO pins
led = 18
led2 = 16
motor1 = 22
motor2 = 27
motor3 = 17
dhtpin = 5
#GPIO.setmode(GPIO.BCM)
#GPIO.setup(led, GPIO.OUT)
#GPIO.setup(motor1, GPIO.OUT)
#GPIO.setup(motor2, GPIO.OUT)
#GPIO.setup(motor3, GPIO.OUT)
#dht = DHT.DHT(dhtpin)

#Setup Email
sender = 'johnyjohnsoniot@gmail.com'
password = 'lwcd wwbq oeft wojh'
imap = imaplib.IMAP4_SSL('imap.gmail.com', 993)
imap.login(sender, password)

#Setup App
app = dash.Dash(__name__)

#Layouts
#Initial Layout (Login Layout)
app.layout = html.Div(
    id="dashLayout",
    children=[
        html.H1(
            children="Smart Home Dashboard"
        ),
        html.P(
            id="placeholder",
            className=""
        ),
        html.P(
            id="placeholder2",
            className=""
        ),
        html.Div(
            id="content",
            children=[
                html.H1('Login'),
                dcc.Input(
                    id='rfid',
                    type='text',
                    placeholder='rfid'
                ),
                html.Button(
                    'Submit',
                    id='submit-button'
                )
            ]
        ),
        html.Img(
            id="light-image",
            src="/assets/lightbulb-off.png",
            style={"height": "50px", "display": "inline-block", "vertical-align": "middle", "margin-left": "10px"},
        ),
        daq.BooleanSwitch(
            id="light-switch",
            label="Light",
            on=False,
            style={"display": "inline-block", "vertical-align": "middle"},
        ),
        daq.Gauge(
            id="temp-gauge",
            label="Temperature",
            value=random.uniform(0, 50),
            color={"gradient":True,"ranges":{"blue":[0,12],"green":[12,24],"yellow":[24,36],"red":[36,50]}},
            min=0,
            max=50,
            showCurrentValue=True,
            units="C",
        ),
        daq.Gauge(
            id="humidity-gauge",
            label="Humidity",
            value=random.uniform(0, 100),
            color={"gradient":True,"ranges":{"white":[0,50],"blue":[51,100]}},
            min=0,
            max=100,
            showCurrentValue=True,
            units="%",
        ),
        daq.GraduatedBar(
            id="light-bar",
            label="Light Level",
            value=random.uniform(0, 1000),
            min=0,
            max=1000,
            step=50,
            showCurrentValue=True,
        ),
        html.Div(
            id="email-notification",
            children="",
            style={'textAlign':'center', 'color':'white'}
        ),
        dcc.Interval(
            id='interval-component',
            interval=10000,
            n_intervals=0
        )
    ]
)

#Functions/Callbacks
def on_message(client, userdata, msg):
    global light_in, last_rfid_message
    if msg.topic == "lightIntensity":
        light_in = int(msg.payload.decode("utf-8"))
    elif msg.topic == "IoTLab/rfid":
        last_rfid_message = msg.payload.decode("utf-8")

mqtt_client_instance = mqtt_client.Client()
mqtt_client_instance.on_message = on_message
mqtt_client_instance.connect("192.168.2.67")
mqtt_client_instance.subscribe("lightIntensity")
mqtt_client_instance.subscribe("IoTLab/rfid")
mqtt_client_instance.loop_start()

#Getters/Setters
def set_accountId(value):
    global accountId
    accountId = value

def set_accountId(value):
    global accountId
    accountId = value
    
def set_email(value):
    global receiver
    receiver = value

def get_email(value):
    global receiver
    receiver = value

def set_temp(value):
    global temp
    temp = value

def get_temp():
    global temp
    return temp

def set_humid(value):
    global humid
    humid = value

def get_humid():
    global humid
    return humid
    
def set_light(value):
    global light
    light = value

def get_light():
    global light
    return light

#Login
@app.callback(
    Output('content', 'children', allow_duplicate=True),
    [Input('submit-button', 'n_clicks'),
     Input('rfid', 'value')],
    prevent_initial_call=True,
)
def login(n_clicks, dcc_value):
    conn = sqlite3.connect('data/dashboard_db')
    c = conn.cursor()
    c.execute("""
    SELECT * FROM account WHERE id = ?
    """, (dcc_value,))
    result = c.fetchone()
    conn.commit()
    if result:
        set_accountId(dcc_value)
        #set_email(result[1])
        set_temp(result[2])
        set_light(result[3])
        children = html.Button('Create Account',id="create-account"), html.Button('Logout',id="logout-button")
        return children

#Account Creation Layout Change
@app.callback(
    Output('content', 'children', allow_duplicate=True),
    [Input('create-account', 'n_clicks')],
    prevent_initial_call=True
)
def createAccount(n_clicks):
    if n_clicks == None:
        children = html.Button('Create Account',id="create-account"), html.Button('Logout',id="logout-button")
        return children
    else:
        set_accountId(0)
        set_temp(0)
        set_light(0)
        children=html.H1('Create Account'), dcc.Input(id='rfidCreate',type='text',placeholder='rfid'), dcc.Input(id='email',type='text',placeholder='email'), dcc.Input(id='temp-pref',type='text',placeholder='temperature preference'), dcc.Input(id='light-pref',type='text',placeholder='light preference'), html.Button('Create',id='create-button')
        return children
        
#Commit Account Creation
@app.callback(
    Output('content', 'children', allow_duplicate=True),
    [Input('create-button', 'n_clicks'),
     Input('rfidCreate', 'rfidValue'),
     Input('email', 'emailValue'),
     Input('temp-pref', 'tempValue'),
     Input('light-pref', 'lightValue')],
    prevent_initial_call=True
)
def commitAccount(n_clicks, rfidValue, emailValue, tempValue, lightValue):
    if n_clicks == None:
        children = children=html.H1('Create Account'), dcc.Input(id='rfidCreate',type='text',placeholder='rfid'), dcc.Input(id='email',type='text',placeholder='email'), dcc.Input(id='temp-pref',type='text',placeholder='temperature preference'), dcc.Input(id='light-pref',type='text',placeholder='light preference'), html.Button('Create',id='create-button')
        return children
    else:
        conn = sqlite3.connect('data/dashboard_db')
        c = conn.cursor()
        c.execute("""
        INSERT INTO account VALUES(?,?,?,?)
        """, (rfidValue, emailValue, tempValue, lightValue,)
        )
        conn.commit()
        
        children = html.Button('Create Account',id="create-account"), html.Button('Logout',id="logout-button")
        return children

#Logout
@app.callback(
    Output('content', 'children', allow_duplicate=True),
    [Input('logout-button', 'n_clicks')],
    prevent_initial_call=True
)
def logout(n_clicks):
    if n_clicks == None:
        children = html.Button('Create Account',id="create-account"), html.Button('Logout',id="logout-button")
        return children
    else:
        set_accountId(0)
        set_temp(0)
        set_light(0)
        children=html.H1('Login'), dcc.Input(id='rfid',type='text',placeholder='rfid'), html.Button('Submit',id='submit-button')
        return children
    

#Light Switch
@app.callback(
    Output("light-image", "src"),
    [Input("light-switch", "on")],
)
def update_light_image(on):
    if on:
        #GPIO.output(led, GPIO.HIGH)
        return "/assets/lightbulb-on.png"
    else:
        #GPIO.output(led, GPIO.LOW)
        return "/assets/lightbulb-off.png"

#Update Temperature Gauge
@app.callback(
    Output('temp-gauge', 'value'),
    [Input('interval-component', 'n_intervals')]
)
def update_temperature(n):
    #temp = dht.temperature
    temp = randint(0,50)
    if temp>get_temp():
        subject = 'Dashboard: High Temperature Detected'
        body = """
        A high temperature has been recorded, please reply 'Yes' to turn on the fan.
        """
        email = EmailMessage()
        email['From'] = sender
        email['To'] = receiver
        email['Subject'] = subject
        email.set_content(body)
        
        context=ssl.create_default_context()
        
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
             smtp.login(sender, password)
             smtp.sendmail(sender, receiver, email.as_string())
    return temp

#Update Humidity Gauge
@app.callback(
    Output('humidity-gauge', 'value'),
    [Input('interval-component', 'n_intervals')]
)
def update_humidity(n):
    #humid = dht.humidity
    humid = randint(0, 100)
    return humid

#Update Photosensitivity Bar    
@app.callback(
    [Output('light-bar', 'value'),
     Output('email-notification', 'children')],
    [Input('interval-component', 'n_intervals')]
)
def update_light(n):
    light = randint(0, 1000)
    if light < get_light():
        subject = 'Dashboard: Low Light Detected'
        body = """
        It's getting dark, lights have been activated.
        """
        email = EmailMessage()
        email['From'] = sender
        email['To'] = receiver
        email['Subject'] = subject
        email.set_content(body)
        
        context=ssl.create_default_context()
        
        with smtplib.SMTP_SSL('smtp.gmail.com', 465, context=context) as smtp:
            smtp.login(sender, password)
            smtp.sendmail(sender, receiver, email.as_string())
        children = "Email Notification Sent"
        #GPIO.output(led, GPIO.HIGH)
    else:
        children = ""
        #GPIO.output(led, GPIO.LOW)
    return light, children

#Update Database Readings    
@app.callback(Output('placeholder', 'className'),
            [Input('interval-component', 'n_intervals')])
def update_db(self):
    now = str(datetime.now())
    
    conn = sqlite3.connect('data/dashboard_db')
    c = conn.cursor()
    
    c.execute("""
    INSERT INTO readings VALUES(?,?,?,?)
    """, (now, get_temp(), get_humid(), get_light()))#(now, dht.temperature, dht.humidity, )
    
    conn.commit()
    
"""@app.callback(Output('placeholder2', 'className'),
             [Input('interval-component', 'n_intervals')])
def search_mail(self):
    body_text = 'Yes'
    query = f'(FROM "{receiver}" SUBJECT "Re:" BODY "{body_text}")'
    email_msg=""
    imap.select('Inbox')
    result, data = imap.search(None, query)
    for msg_id in data[0].split():
        result, msg_data = imap.fetch(msg_id, "(RFC822)")
        raw_email = msg_data[0][1]
        email_msg = email.message_from_bytes(raw_email)
        sender_email = email_msg['From']
        subject = email_msg['Subject']
        body = None
        if email_msg.is_multipart():
            for part in email_msg.walk():
                content_type = part.get_content_type()
                if content_type == 'text/plain':
                    body = part.get_payload(decode=True).decode('utf-8')
    else:
        body = email_msg.get_payload(decode=True).decode('utf-8')
    if sender_email == receiver and body_text in body:
        print(f"Reply from {sender_email} with subject '{subject}' found.")
        imap.expunge()
    else:
        print("No Mail")"""

#Run App
if __name__ == "__main__":
    app.run_server(debug=True)
